# mon_premier_essai.py
# OM 2020.03.12 Essai programme
print("Tais-toi l'individu Mondial sur la terre")
